# UiPath_RPA_Hackathon_Level2
RPA Hackathon Vincix Solution Level 2. UiPath.

Level 2:
There are 10 rounds :
5 rounds where you have to fill 7 fields, and fields will change position on the screen after every submission and there will be 4 random popup’s with an instruction to click a button.
4 rounds where you have to find an image that contains text inside a matrix and insert the position in the fields.
During the level you will find 2 numbers… memorise these! Becouse the in the last round you have to use in order to resolve the last question.
